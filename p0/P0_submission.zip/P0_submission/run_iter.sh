#!/bin/bash
echo "Tiny"
./iter_count_words.py tiny

echo "Small"
./iter_count_words.py small

echo "Medium"
./iter_count_words.py medium

echo "Large"
./iter_count_words.py big
