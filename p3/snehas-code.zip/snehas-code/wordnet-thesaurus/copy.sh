cp robust04.qrels-ndcg10 ../plots/wn-robust-com-ndcg10.dat
cp robust04.qrels-prec10 ../plots/wn-robust-com-prec10.dat
cp robust.qrels-prec10 ../plots/wn-robust-class-prec10.dat
cp robust.qrels-ndcg10 ../plots/wn-robust-class-ndcg10.dat
cp books.qrels-ndcg10 ../plots/wn-books-class-ndcg10.dat
cp books.qrels-prec10 ../plots/wn-books-class-prec10.dat
