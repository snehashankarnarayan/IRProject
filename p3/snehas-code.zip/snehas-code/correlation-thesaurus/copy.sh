cp robust04.qrels-ndcg10 ../plots/cor-robust-com-ndcg10.dat
cp robust04.qrels-prec10 ../plots/cor-robust-com-prec10.dat
cp robust.qrels-prec10 ../plots/cor-robust-class-prec10.dat
cp robust.qrels-ndcg10 ../plots/cor-robust-class-ndcg10.dat
cp books.qrels-ndcg10 ../plots/cor-books-class-ndcg10.dat
cp books.qrels-prec10 ../plots/cor-books-class-prec10.dat
