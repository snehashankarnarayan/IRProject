#!/usr/bin/python

class judgements:
    def __init__(self, query, rel):
        #Globals
        self.query = query
        self.rel = rel
